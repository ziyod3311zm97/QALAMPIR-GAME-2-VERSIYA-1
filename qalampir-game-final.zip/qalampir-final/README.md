# 🌶️ Qalampir Game

Telegram Mini App'i uchun real-time 1v1 PvP o'yin — do'zax qalampirni maydonda yashiring, raqib uni topsin!

## ✨ Xususiyatlar

- 🎮 **Real-time 1v1 jang** (Socket.IO) — tezkor moslashtiruv, 6 soniyada bot raqib
- 🔑 **Do'st bilan o'ynash** — 4 xonali xona kodi orqali
- 💰 **Coin iqtisodiyoti** — g'alaba, kunlik bonus, referral
- 🤝 **Referral tizimi** — do'stni taklif qil, ikkalangiz ham bonus oling
- 🏁 **Star Race** — kunlik referral musobaqasi, TOP-10'ga Telegram Stars mukofoti
- 👕 **Skinlar** — 7 xil noyoblikda qalampir skinlari
- 🎨 **11 ta mavzu (theme)**
- ⭐ **Telegram Stars orqali coin sotib olish**
- 🛠 **Admin panel** — bot buyruqlari orqali (statistika, ban, broadcast, Star Race to'lovlari)

## 📁 Tuzilma

```
├── server.js              # Express + Socket.IO asosiy fayl
├── database/               # PostgreSQL bilan ishlash (pool, sxema, CRUD)
├── services/                # Biznes-logika (o'yin, referral, star race, anti-cheat)
├── routes/                  # REST API endpointlari
├── bot/                     # Telegram bot (buyruqlar, to'lovlar)
└── public/                  # Frontend (Telegram WebApp)
```

## 🚀 O'rnatish

```bash
npm install
cp .env.example .env
# .env faylini to'ldiring: BOT_TOKEN, DATABASE_URL, WEB_APP_URL, ADMIN_IDS
npm start
```

Server birinchi ishga tushganda kerakli barcha jadvallarni (`users`, `transactions`, `stars_payments`, `star_race_payouts`) avtomatik yaratadi.

## ⚙️ .env sozlamalari

| O'zgaruvchi | Tavsif |
|---|---|
| `BOT_TOKEN` | @BotFather'dan olingan bot tokeni |
| `DATABASE_URL` | PostgreSQL ulanish satri |
| `WEB_APP_URL` | Mini App joylashgan domen (Render va h.k.) |
| `BOT_USERNAME` | Referral link yaratish uchun bot username'i |
| `ADMIN_IDS` | Admin buyruqlariga ruxsat berilgan Telegram ID'lar, vergul bilan |

## 🛠 Admin buyruqlari (botda)

`/admin`, `/stats`, `/revenue`, `/finduser`, `/addcoins`, `/ban`, `/unban`, `/broadcast`, `/topref`

### Star Race admin buyruqlari

- `/racesnapshot [YYYY-MM-DD]` — kunni "muzlatish": o'sha kungi TOP-10'ni saqlab qo'yadi
- `/racelist` — hali to'lanmagan mukofotlar ro'yxati
- `/racepay <payout_id>` — Stars'ni qo'lda yuborgach, "to'landi" deb belgilash

> ⚠️ Star Race mukofotlari (Telegram Stars) hozircha **qo'lda** beriladi — Bot API orqali haqiqiy Stars'ni avtomatik yuborishning ishonchli usuli yo'q, shu sababli admin buyruqlar orqali kuzatib boriladi.

## 🧪 Test qilingan

Bu versiya lokal PostgreSQL va real socket.io mijoz bilan to'liq sinovdan o'tkazilgan:
- Foydalanuvchi yaratish + referral bonusi ✅
- Kunlik bonus (va takroriy urinishni bloklash) ✅
- Leaderboard ✅
- Skin sotib olish/kiyish ✅
- Mavzu o'zgartirish ✅
- Star Race hisob-kitobi ✅
- To'liq real-time o'yin aylanishi: navbat → moslashtiruv → yashirish → jang → g'olibni aniqlash ✅
