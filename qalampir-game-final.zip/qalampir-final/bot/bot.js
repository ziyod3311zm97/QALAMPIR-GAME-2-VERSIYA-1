const TelegramBot = require("node-telegram-bot-api");

const { COIN_PACKAGES, recordStarsPayment } = require("../database/payments");
const { addCoins } = require("../database/users");

const { registerStartHandlers } = require("./start");
const { registerAdminCommands } = require("./commands");
const { registerReferralCommands } = require("./referral");


function createBot(WEB_APP_URL) {

  const BOT_TOKEN = process.env.BOT_TOKEN;

  if (!BOT_TOKEN) {
    console.error("⚠️  BOT_TOKEN topilmadi — bot ishga tushmaydi, Stars to'lovlari o'chirilgan.");
    return null;
  }

  const bot = new TelegramBot(BOT_TOKEN, { polling: true });


  /* =====================================================
     TO'LOV (Telegram Stars)
  ===================================================== */

  bot.on("pre_checkout_query", async query => {
    try {
      await bot.answerPreCheckoutQuery(query.id, true);
    } catch (error) {
      console.error("Pre-checkout xatosi:", error);
    }
  });

  bot.on("message", async msg => {
    if (!msg.successful_payment) return;

    try {
      const payload = JSON.parse(msg.successful_payment.invoice_payload);
      const pkg = COIN_PACKAGES[payload.packageId];

      if (pkg) {
        await addCoins(payload.userId, pkg.coins, "stars_purchase");

        await recordStarsPayment(
          payload.userId,
          payload.packageId,
          msg.successful_payment.total_amount,
          pkg.coins,
          msg.successful_payment.telegram_payment_charge_id
        );
      }

      await bot.sendMessage(
        msg.chat.id,
        `✅ To'lov qabul qilindi!\n\n+${pkg ? pkg.coins : 0} 🌶️ hisobingizga qo'shildi.`
      );

    } catch (error) {
      console.error("Successful payment xatosi:", error);
    }
  });

  bot.on("polling_error", error => {
    console.error("Bot polling xatosi:", error.message);
  });


  /* =====================================================
     BUYRUQLAR
  ===================================================== */

  registerStartHandlers(bot, WEB_APP_URL);

  const { isAdmin } = registerAdminCommands(bot);
  registerReferralCommands(bot, isAdmin);

  console.log("🤖 Telegram bot ishga tushdi (polling)");

  return bot;
}

module.exports = { createBot };
