const { getAdminStats } = require("../database/admin");
const { getRevenueStats } = require("../database/payments");
const {
  findUserByIdOrUsername,
  setBanned,
  getAllUserIds,
  addCoins
} = require("../database/users");

const starRaceService = require("../services/starRaceService");


/* =====================================================
   ADMIN TEKSHIRUVI
===================================================== */

function makeIsAdmin() {
  const ADMIN_IDS = new Set(
    (process.env.ADMIN_IDS || "")
      .split(",")
      .map(id => id.trim())
      .filter(Boolean)
      .map(Number)
  );

  return userId => ADMIN_IDS.has(Number(userId));
}


/* =====================================================
   ADMIN BUYRUQLARINI ULASH
===================================================== */

function registerAdminCommands(bot) {

  const isAdmin = makeIsAdmin();

  bot.onText(/^\/admin$/, async msg => {
    if (!isAdmin(msg.from.id)) return;

    await bot.sendMessage(
      msg.chat.id,
      "🛠 *ADMIN PANEL*\n\n" +
      "📊 /stats — umumiy statistika\n" +
      "💰 /revenue — Stars daromadi\n" +
      "🔍 /finduser <id yoki @username> — o'yinchini qidirish\n" +
      "💵 /addcoins <id> <miqdor> — coin qo'shish (manfiy son ayiradi)\n" +
      "🚫 /ban <id> — bloklash\n" +
      "✅ /unban <id> — blokdan chiqarish\n" +
      "📢 /broadcast <matn> — hammaga xabar yuborish\n\n" +
      "🏁 *STAR RACE*\n" +
      "📸 /racesnapshot [YYYY-MM-DD] — kunni \"muzlatish\" (top-10 yozib qo'yish)\n" +
      "📋 /racelist — to'lanmagan mukofotlar\n" +
      "✅ /racepay <payout_id> — mukofot berilgach, to'landi deb belgilash",
      { parse_mode: "Markdown" }
    );
  });


  bot.onText(/^\/stats$/, async msg => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const stats = await getAdminStats();

      await bot.sendMessage(
        msg.chat.id,
        "📊 *STATISTIKA*\n\n" +
        `👥 Jami o'yinchilar: ${stats.total_users}\n` +
        `🌶️ Aylanmadagi coin: ${stats.total_coins}\n` +
        `🏆 Jami o'yinlar: ${stats.total_games}\n` +
        `🚫 Bloklangan: ${stats.total_banned}`,
        { parse_mode: "Markdown" }
      );

    } catch (error) {
      console.error("Admin stats xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });


  bot.onText(/^\/revenue$/, async msg => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const revenue = await getRevenueStats(10);

      const recentText =
        revenue.recent.length === 0
          ? "Hali xaridlar yo'q."
          : revenue.recent
              .map(r => {
                const name = r.first_name || r.username || r.user_id;
                return `• ${name}: ${r.stars_amount}⭐ → ${r.coins_amount}🌶️`;
              })
              .join("\n");

      await bot.sendMessage(
        msg.chat.id,
        "💰 *STARS DAROMADI*\n\n" +
        `⭐ Jami: ${revenue.totalStars} Stars\n` +
        `🛒 Xaridlar soni: ${revenue.totalPurchases}\n\n` +
        "So'nggi xaridlar:\n" + recentText,
        { parse_mode: "Markdown" }
      );

    } catch (error) {
      console.error("Revenue xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });


  bot.onText(/^\/finduser (\S+)$/, async (msg, match) => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const user = await findUserByIdOrUsername(match[1]);

      if (!user) {
        bot.sendMessage(msg.chat.id, "Topilmadi.");
        return;
      }

      await bot.sendMessage(
        msg.chat.id,
        `👤 ${user.first_name || "-"} (@${user.username || "-"})\n` +
        `ID: \`${user.id}\`\n` +
        `🌶️ Balans: ${user.balance}\n` +
        `🏆 G'alaba: ${user.wins} | ❌ Mag'lubiyat: ${user.losses}\n` +
        `🔋 Jon: ${user.energy}/5\n` +
        `${user.is_banned ? "🚫 BLOKLANGAN" : "✅ Faol"}`,
        { parse_mode: "Markdown" }
      );

    } catch (error) {
      console.error("Finduser xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });


  bot.onText(/^\/addcoins (\S+) (-?\d+)$/, async (msg, match) => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const userId = Number(match[1]);
      const amount = Number(match[2]);

      const updated = await addCoins(userId, amount, "admin_adjustment");

      await bot.sendMessage(
        msg.chat.id,
        `✅ Yangilandi.\n\nYangi balans: ${updated.balance} 🌶️`
      );

    } catch (error) {
      console.error("Addcoins xatosi:", error);
      bot.sendMessage(msg.chat.id, "Foydalanuvchi topilmadi yoki xatolik yuz berdi.");
    }
  });


  bot.onText(/^\/ban (\d+)$/, async (msg, match) => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const updated = await setBanned(Number(match[1]), true);
      bot.sendMessage(msg.chat.id, updated ? "🚫 Bloklandi." : "Foydalanuvchi topilmadi.");
    } catch (error) {
      console.error("Ban xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });


  bot.onText(/^\/unban (\d+)$/, async (msg, match) => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const updated = await setBanned(Number(match[1]), false);
      bot.sendMessage(msg.chat.id, updated ? "✅ Blokdan chiqarildi." : "Foydalanuvchi topilmadi.");
    } catch (error) {
      console.error("Unban xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });


  bot.onText(/^\/broadcast ([\s\S]+)$/, async (msg, match) => {
    if (!isAdmin(msg.from.id)) return;

    const text = match[1];

    try {
      const ids = await getAllUserIds();

      await bot.sendMessage(msg.chat.id, `📢 Yuborilmoqda: ${ids.length} ta foydalanuvchiga...`);

      let success = 0;
      let failed = 0;

      for (const id of ids) {
        try {
          await bot.sendMessage(id, text);
          success += 1;
        } catch (sendError) {
          failed += 1;
        }

        await new Promise(resolve => setTimeout(resolve, 40));
      }

      await bot.sendMessage(
        msg.chat.id,
        `✅ Tugadi.\n\nYuborildi: ${success}\nXato: ${failed}`
      );

    } catch (error) {
      console.error("Broadcast xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });


  /* =====================================================
     STAR RACE ADMIN BUYRUQLARI
  ===================================================== */

  bot.onText(/^\/racesnapshot(?:\s+(\d{4}-\d{2}-\d{2}))?$/, async (msg, match) => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const { raceDate, inserted } = await starRaceService.snapshotDay(match[1]);

      if (inserted.length === 0) {
        bot.sendMessage(
          msg.chat.id,
          `📸 ${raceDate} uchun mukofotli g'oliblar topilmadi (yoki allaqachon saqlangan).`
        );
        return;
      }

      const text = inserted
        .map(p => `${p.position}-o'rin — ID ${p.user_id}: ${p.stars}⭐ (payout #${p.id})`)
        .join("\n");

      await bot.sendMessage(
        msg.chat.id,
        `📸 *${raceDate} — Star Race yakunlandi*\n\n${text}\n\n` +
        `Har birini qo'lda to'lagach: /racepay <payout_id>`,
        { parse_mode: "Markdown" }
      );

    } catch (error) {
      console.error("Racesnapshot xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });


  bot.onText(/^\/racelist$/, async msg => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const pending = await starRaceService.listPendingPayouts(30);

      if (pending.length === 0) {
        bot.sendMessage(msg.chat.id, "✅ To'lanmagan mukofotlar yo'q.");
        return;
      }

      const text = pending
        .map(p => {
          const name = p.first_name || p.username || p.user_id;
          return `#${p.id} • ${p.race_date} • ${p.position}-o'rin • ${name}: ${p.stars}⭐`;
        })
        .join("\n");

      await bot.sendMessage(msg.chat.id, `📋 *TO'LANMAGAN MUKOFOTLAR*\n\n${text}`, {
        parse_mode: "Markdown"
      });

    } catch (error) {
      console.error("Racelist xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });


  bot.onText(/^\/racepay (\d+)$/, async (msg, match) => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const updated = await starRaceService.payOut(Number(match[1]), msg.from.id);

      bot.sendMessage(
        msg.chat.id,
        updated
          ? `✅ Payout #${updated.id} to'landi deb belgilandi.`
          : "Payout topilmadi."
      );

    } catch (error) {
      console.error("Racepay xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });

  return { isAdmin };
}


module.exports = {
  registerAdminCommands,
  makeIsAdmin
};
