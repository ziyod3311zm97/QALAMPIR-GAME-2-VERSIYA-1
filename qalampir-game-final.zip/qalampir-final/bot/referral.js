const { getTopReferrers } = require("../services/referralService");


/* =====================================================
   /topref - eng ko'p taklif qilganlar (umumiy)
===================================================== */

function registerReferralCommands(bot, isAdmin) {

  bot.onText(/^\/topref$/, async msg => {
    if (!isAdmin(msg.from.id)) return;

    try {
      const top = await getTopReferrers(10);

      if (top.length === 0) {
        bot.sendMessage(msg.chat.id, "Hali referrallar yo'q.");
        return;
      }

      const text = top
        .map((u, i) => {
          const name = u.first_name || u.username || u.id;
          return `${i + 1}. ${name} — ${u.referral_count} ta`;
        })
        .join("\n");

      await bot.sendMessage(msg.chat.id, `🤝 *TOP REFERRERLAR*\n\n${text}`, {
        parse_mode: "Markdown"
      });

    } catch (error) {
      console.error("Topref xatosi:", error);
      bot.sendMessage(msg.chat.id, "Xatolik yuz berdi.");
    }
  });
}

module.exports = { registerReferralCommands };
