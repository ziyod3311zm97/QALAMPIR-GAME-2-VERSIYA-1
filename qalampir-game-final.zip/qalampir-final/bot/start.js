/* =====================================================
   /start VA /game BUYRUQLARI
   Referral deep-link: https://t.me/<bot>?start=ref_12345
===================================================== */

function buildWebAppUrl(baseUrl, referralCode) {
  if (!referralCode) {
    return baseUrl;
  }

  const separator = baseUrl.includes("?") ? "&" : "?";

  return `${baseUrl}${separator}startapp=ref_${referralCode}`;
}

function registerStartHandlers(bot, WEB_APP_URL) {

  bot.onText(/^\/start(?:\s+ref_(\d+))?$/, async (msg, match) => {
    try {
      const referralCode = match && match[1] ? match[1] : null;
      const firstName = msg.from?.first_name || "Do'st";
      const webAppUrl = buildWebAppUrl(WEB_APP_URL, referralCode);

      await bot.sendMessage(
        msg.chat.id,
        `🌶️ Salom, ${firstName}!\n\n` +
        `🔥 QALAMPIR GAME'ga xush kelibsiz!\n\n` +
        `🎮 O'yinni boshlash uchun pastdagi tugmani bosing.`,
        {
          reply_markup: {
            inline_keyboard: [[
              { text: "🌶️ QALAMPIR GAME", web_app: { url: webAppUrl } }
            ]]
          }
        }
      );

    } catch (error) {
      console.error("❌ /start xatosi:", error);
    }
  });

  bot.onText(/^\/game$/, async msg => {
    try {
      await bot.sendMessage(
        msg.chat.id,
        "🌶️ QALAMPIR GAME",
        {
          reply_markup: {
            inline_keyboard: [[
              { text: "🎮 O'yinni ochish", web_app: { url: WEB_APP_URL } }
            ]]
          }
        }
      );

    } catch (error) {
      console.error("❌ /game xatosi:", error);
    }
  });

  bot.onText(/^\/help$/, async msg => {
    await bot.sendMessage(
      msg.chat.id,
      "🌶️ QALAMPIR GAME\n\n" +
      "🎮 O'yinni boshlash uchun /start buyrug'ini yuboring.\n" +
      "🔥 Keyin «QALAMPIR GAME» tugmasini bosing."
    );
  });
}

module.exports = {
  registerStartHandlers,
  buildWebAppUrl
};
