const { pool } = require("./db");


/* =====================================================
   UMUMIY STATISTIKA
===================================================== */

async function getAdminStats() {
  const result = await pool.query(`
    SELECT
      COUNT(*)::int AS total_users,
      COALESCE(SUM(balance), 0)::bigint AS total_coins,
      COALESCE(SUM(wins + losses), 0)::bigint AS total_games,
      COUNT(*) FILTER (WHERE is_banned)::int AS total_banned
    FROM users
  `);

  return result.rows[0];
}


module.exports = {
  getAdminStats
};
