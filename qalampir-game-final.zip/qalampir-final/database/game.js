const {
  pool,
  GAME_WIN_REWARD,
  GAME_WIN_XP,
  GAME_LOSS_XP
} = require("./db");


/* =====================================================
   O'YIN NATIJASINI SAQLASH
===================================================== */

async function updateGameResult(userId, result) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const userResult = await client.query(
      `SELECT * FROM users WHERE id = $1 FOR UPDATE`,
      [userId]
    );

    if (userResult.rows.length === 0) {
      throw new Error("Foydalanuvchi topilmadi");
    }

    const user = userResult.rows[0];

    let balanceChange = 0;
    let newWins = user.wins;
    let newLosses = user.losses;
    let newStreak = user.streak;
    let xpChange = 0;
    let transactionType = "";

    if (result === "win") {
      balanceChange = GAME_WIN_REWARD;
      newWins += 1;
      newStreak += 1;
      xpChange = GAME_WIN_XP;
      transactionType = "game_win";
    } else if (result === "loss") {
      balanceChange = 0;
      newLosses += 1;
      newStreak = 0;
      xpChange = GAME_LOSS_XP;
      transactionType = "game_loss";
    } else {
      throw new Error("Noto'g'ri o'yin natijasi");
    }

    const newBalance = Math.max(
      0,
      Number(user.balance) + balanceChange
    );

    const newXp = Number(user.xp) + xpChange;

    const newLevel = Math.max(
      1,
      Math.floor(newXp / 100) + 1
    );

    const updated = await client.query(
      `
      UPDATE users
      SET
        balance = $1,
        wins = $2,
        losses = $3,
        streak = $4,
        xp = $5,
        level = $6,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $7
      RETURNING *
      `,
      [
        newBalance,
        newWins,
        newLosses,
        newStreak,
        newXp,
        newLevel,
        userId
      ]
    );

    await client.query(
      `INSERT INTO transactions (user_id, amount, type) VALUES ($1, $2, $3)`,
      [userId, balanceChange, transactionType]
    );

    await client.query("COMMIT");

    return updated.rows[0];

  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}


module.exports = {
  updateGameResult
};
