const { pool } = require("./db");


/* =====================================================
   BALANCE BO'YICHA LEADERBOARD
===================================================== */

async function getLeaderboard(limit = 20) {
  const safeLimit = Math.min(Math.max(Number(limit) || 20, 1), 100);

  const result = await pool.query(
    `
    SELECT
      id, username, first_name,
      balance, wins, losses, streak, level, xp
    FROM users
    WHERE is_banned = false
    ORDER BY balance DESC, id ASC
    LIMIT $1
    `,
    [safeLimit]
  );

  return result.rows;
}


module.exports = {
  getLeaderboard
};
