const { pool } = require("./db");


/* =====================================================
   COIN PAKETLARI (Telegram Stars orqali sotib olinadi)
===================================================== */

const COIN_PACKAGES = {
  small: {
    id: "small",
    coins: 500,
    stars: 50,
    label: "500 🌶️"
  },
  medium: {
    id: "medium",
    coins: 1200,
    stars: 100,
    label: "1200 🌶️ (+20% bonus)"
  },
  large: {
    id: "large",
    coins: 3000,
    stars: 200,
    label: "3000 🌶️ (+50% bonus)"
  }
};


/* =====================================================
   STARS TO'LOVINI QAYD ETISH
===================================================== */

async function recordStarsPayment(
  userId,
  packageId,
  starsAmount,
  coinsAmount,
  chargeId
) {
  await pool.query(
    `
    INSERT INTO stars_payments (
      user_id, package_id, stars_amount, coins_amount, telegram_charge_id
    )
    VALUES ($1, $2, $3, $4, $5)
    `,
    [userId, packageId, starsAmount, coinsAmount, chargeId || null]
  );
}


/* =====================================================
   DAROMAD STATISTIKASI (admin uchun)
===================================================== */

async function getRevenueStats(limit = 10) {
  const totals = await pool.query(`
    SELECT
      COALESCE(SUM(stars_amount), 0)::bigint AS total_stars,
      COUNT(*)::int AS total_purchases
    FROM stars_payments
  `);

  const recent = await pool.query(
    `
    SELECT
      sp.stars_amount, sp.coins_amount, sp.created_at,
      u.first_name, u.username, u.id AS user_id
    FROM stars_payments sp
    JOIN users u ON u.id = sp.user_id
    ORDER BY sp.created_at DESC
    LIMIT $1
    `,
    [limit]
  );

  return {
    totalStars: totals.rows[0].total_stars,
    totalPurchases: totals.rows[0].total_purchases,
    recent: recent.rows
  };
}


module.exports = {
  COIN_PACKAGES,
  recordStarsPayment,
  getRevenueStats
};
