const { pool } = require("./db");


/* =====================================================
   USERNING REFERRERINI OLISH
===================================================== */

async function getReferralInfo(userId) {
  const result = await pool.query(
    `
    SELECT
      u.id, u.referred_by,
      r.username AS referrer_username,
      r.first_name AS referrer_first_name
    FROM users u
    LEFT JOIN users r ON r.id = u.referred_by
    WHERE u.id = $1
    `,
    [userId]
  );

  return result.rows[0] || null;
}


/* =====================================================
   NECHTA REFERRAL BOR? (jami)
===================================================== */

async function getReferralCount(userId) {
  const result = await pool.query(
    `SELECT COUNT(*)::int AS count FROM users WHERE referred_by = $1`,
    [userId]
  );

  return result.rows[0].count;
}


/* =====================================================
   BUGUNGI REFERRALLAR SONI (Star Race uchun)
===================================================== */

async function getTodayReferralCount(userId) {
  const result = await pool.query(
    `
    SELECT COUNT(*)::int AS count
    FROM users
    WHERE referred_by = $1
      AND created_at >= CURRENT_DATE
    `,
    [userId]
  );

  return result.rows[0].count;
}


/* =====================================================
   REFERRAL QILINGAN USERLAR RO'YXATI
===================================================== */

async function getReferrals(userId, limit = 100) {
  const result = await pool.query(
    `
    SELECT id, username, first_name, created_at
    FROM users
    WHERE referred_by = $1
    ORDER BY created_at DESC
    LIMIT $2
    `,
    [userId, limit]
  );

  return result.rows;
}


/* =====================================================
   UMUMIY REFERRAL LEADERBOARD (jami vaqt)
===================================================== */

async function getReferralLeaderboard(limit = 10) {
  const result = await pool.query(
    `
    SELECT
      u.id, u.username, u.first_name,
      COUNT(r.id)::int AS referral_count
    FROM users u
    LEFT JOIN users r ON r.referred_by = u.id
    WHERE u.is_banned = false
    GROUP BY u.id, u.username, u.first_name
    ORDER BY referral_count DESC, u.created_at ASC
    LIMIT $1
    `,
    [limit]
  );

  return result.rows;
}


module.exports = {
  getReferralInfo,
  getReferralCount,
  getTodayReferralCount,
  getReferrals,
  getReferralLeaderboard
};
