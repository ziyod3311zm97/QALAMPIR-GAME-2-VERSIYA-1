const { pool, DAILY_BONUS_AMOUNT } = require("./db");


/* =====================================================
   KUNLIK BONUS OLISH
===================================================== */

async function claimDailyBonus(userId) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const result = await client.query(
      `SELECT * FROM users WHERE id = $1 FOR UPDATE`,
      [userId]
    );

    if (result.rows.length === 0) {
      throw new Error("Foydalanuvchi topilmadi");
    }

    const user = result.rows[0];

    if (user.is_banned) {
      const error = new Error("Foydalanuvchi bloklangan");
      error.code = "BANNED";
      throw error;
    }

    const alreadyToday = await client.query(
      `SELECT (last_bonus_date = CURRENT_DATE) AS claimed FROM users WHERE id = $1`,
      [userId]
    );

    if (alreadyToday.rows[0].claimed) {
      const error = new Error("Bugungi bonus allaqachon olingan");
      error.code = "ALREADY_CLAIMED";
      throw error;
    }

    const updated = await client.query(
      `
      UPDATE users
      SET
        balance = balance + $1,
        last_bonus_date = CURRENT_DATE,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *
      `,
      [DAILY_BONUS_AMOUNT, userId]
    );

    await client.query(
      `INSERT INTO transactions (user_id, amount, type) VALUES ($1, $2, 'daily_bonus')`,
      [userId, DAILY_BONUS_AMOUNT]
    );

    await client.query("COMMIT");

    return {
      user: updated.rows[0],
      amount: DAILY_BONUS_AMOUNT
    };

  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}


/* =====================================================
   DAILY BONUS HOLATINI TEKSHIRISH
===================================================== */

function isDailyBonusAvailable(user) {
  return (
    !user.last_bonus_date ||
    new Date(user.last_bonus_date).toDateString() !==
      new Date().toDateString()
  );
}


module.exports = {
  claimDailyBonus,
  isDailyBonusAvailable
};
