const { pool, SKINS } = require("./db");
const { getUser } = require("./users");


/* =====================================================
   SKIN KATALOGI
===================================================== */

function buildSkinCatalog(user) {
  const owned = user.owned_skins || ["chili_v1"];

  return Object.values(SKINS).map(skin => ({
    ...skin,
    owned: owned.includes(skin.id),
    equipped: user.equipped_skin === skin.id
  }));
}

async function getSkinCatalog(userId) {
  const user = await getUser(userId);

  if (!user) {
    throw new Error("Foydalanuvchi topilmadi");
  }

  return buildSkinCatalog(user);
}


/* =====================================================
   SKIN SOTIB OLISH / KIYISH
===================================================== */

async function buySkin(userId, skinId) {
  const skin = SKINS[skinId];

  if (!skin) {
    const error = new Error("Skin topilmadi");
    error.code = "SKIN_NOT_FOUND";
    throw error;
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const result = await client.query(
      `SELECT * FROM users WHERE id = $1 FOR UPDATE`,
      [userId]
    );

    if (result.rows.length === 0) {
      throw new Error("Foydalanuvchi topilmadi");
    }

    const user = result.rows[0];
    const owned = user.owned_skins || ["chili_v1"];

    if (owned.includes(skinId)) {
      const updated = await client.query(
        `
        UPDATE users
        SET equipped_skin = $1, updated_at = CURRENT_TIMESTAMP
        WHERE id = $2
        RETURNING *
        `,
        [skinId, userId]
      );

      await client.query("COMMIT");
      return updated.rows[0];
    }

    if (Number(user.balance) < skin.price) {
      const error = new Error("Coin yetarli emas");
      error.code = "NOT_ENOUGH_COINS";
      throw error;
    }

    const newOwned = [...owned, skinId];

    const updated = await client.query(
      `
      UPDATE users
      SET
        balance = balance - $1,
        owned_skins = $2,
        equipped_skin = $3,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $4
      RETURNING *
      `,
      [skin.price, newOwned, skinId, userId]
    );

    await client.query(
      `INSERT INTO transactions (user_id, amount, type) VALUES ($1, $2, 'skin_purchase')`,
      [userId, -skin.price]
    );

    await client.query("COMMIT");

    return updated.rows[0];

  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}


module.exports = {
  getSkinCatalog,
  buySkin
};
