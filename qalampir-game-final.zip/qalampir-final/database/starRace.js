const { pool, STAR_RACE_PRIZE_POOL, STAR_RACE_REWARDS } = require("./db");


/* =====================================================
   RACE HOLATI (UTC 00:00 - 24:00 asosida, har kuni reset)
===================================================== */

function getRaceStatus() {
  const now = new Date();

  const start = new Date(now);
  start.setUTCHours(0, 0, 0, 0);

  const end = new Date(start);
  end.setUTCHours(24, 0, 0, 0);

  const remainingMs = Math.max(0, end.getTime() - now.getTime());

  return {
    active: remainingMs > 0,
    startAt: start.toISOString(),
    endAt: end.toISOString(),
    remainingMs,
    remainingSeconds: Math.floor(remainingMs / 1000),
    prizePool: STAR_RACE_PRIZE_POOL
  };
}

function getRemainingTime() {
  const status = getRaceStatus();
  const totalSeconds = status.remainingSeconds;

  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return {
    hours,
    minutes,
    seconds,
    totalSeconds,
    formatted:
      `${String(hours).padStart(2, "0")}:` +
      `${String(minutes).padStart(2, "0")}:` +
      `${String(seconds).padStart(2, "0")}`
  };
}


/* =====================================================
   KUNLIK LEADERBOARD
   (score = shu kun ichida qilingan referrallar soni)
===================================================== */

async function getDailyReferralLeaderboard(limit = 10, raceDate = null) {
  const safeLimit = Math.min(Math.max(Number(limit) || 10, 1), 100);

  // raceDate berilmasa - bugungi kun (server UTC bo'yicha).
  const dateFilter = raceDate
    ? `r.created_at::date = $2::date`
    : `r.created_at >= CURRENT_DATE`;

  const params = raceDate
    ? [safeLimit, raceDate]
    : [safeLimit];

  const result = await pool.query(
    `
    SELECT
      u.id, u.username, u.first_name,
      COUNT(r.id)::int AS referral_count
    FROM users u
    LEFT JOIN users r
      ON r.referred_by = u.id
      AND ${dateFilter}
    WHERE u.is_banned = false
    GROUP BY u.id, u.username, u.first_name
    HAVING COUNT(r.id) > 0
    ORDER BY referral_count DESC, u.id ASC
    LIMIT $1
    `,
    params
  );

  return result.rows.map((row, index) => {
    const reward = STAR_RACE_REWARDS.find(
      item => item.position === index + 1
    );

    return {
      position: index + 1,
      userId: row.id,
      username: row.username,
      firstName: row.first_name,
      score: Number(row.referral_count),
      potentialStars: reward ? reward.stars : 0
    };
  });
}


/* =====================================================
   USERNING RACE HOLATI
===================================================== */

async function getUserRaceStanding(userId) {
  const leaderboard = await getDailyReferralLeaderboard(100);
  const entry = leaderboard.find(item => item.userId === Number(userId));

  if (!entry) {
    return { userId: Number(userId), score: 0, rank: null, potentialStars: 0 };
  }

  return {
    userId: entry.userId,
    score: entry.score,
    rank: entry.position,
    potentialStars: entry.potentialStars
  };
}


/* =====================================================
   RACE MA'LUMOTLARI (frontend uchun to'liq snapshot)
===================================================== */

async function getStarRaceInfo() {
  const status = getRaceStatus();
  const time = getRemainingTime();
  const leaderboard = await getDailyReferralLeaderboard(10);

  return {
    active: status.active,
    startAt: status.startAt,
    endAt: status.endAt,
    remainingMs: status.remainingMs,
    remainingSeconds: status.remainingSeconds,
    countdown: time.formatted,
    prizePool: STAR_RACE_PRIZE_POOL,
    leaderboard,
    rewards: STAR_RACE_REWARDS
  };
}


/* =====================================================
   SNAPSHOT: kunning yakuniy TOP-10'ini
   star_race_payouts jadvaliga "muzlatib" yozib qo'yish.
   (Admin buyrug'i orqali chaqiriladi, odatda kun tugagach.)
===================================================== */

async function snapshotRaceDay(raceDate) {
  const leaderboard = await getDailyReferralLeaderboard(10, raceDate);

  const inserted = [];

  for (const entry of leaderboard) {
    if (entry.potentialStars <= 0) {
      continue;
    }

    const result = await pool.query(
      `
      INSERT INTO star_race_payouts (
        user_id, race_date, position, score, stars
      )
      VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (user_id, race_date) DO NOTHING
      RETURNING *
      `,
      [entry.userId, raceDate, entry.position, entry.score, entry.potentialStars]
    );

    if (result.rows.length > 0) {
      inserted.push(result.rows[0]);
    }
  }

  return inserted;
}


/* =====================================================
   TO'LANMAGAN MUKOFOTLAR RO'YXATI
===================================================== */

async function getPendingPayouts(limit = 50) {
  const result = await pool.query(
    `
    SELECT
      srp.*, u.username, u.first_name
    FROM star_race_payouts srp
    JOIN users u ON u.id = srp.user_id
    WHERE srp.paid = false
    ORDER BY srp.race_date DESC, srp.position ASC
    LIMIT $1
    `,
    [limit]
  );

  return result.rows;
}


/* =====================================================
   MUKOFOTNI "TO'LANDI" DEB BELGILASH
===================================================== */

async function markPayoutPaid(payoutId, adminId) {
  const result = await pool.query(
    `
    UPDATE star_race_payouts
    SET paid = true, paid_at = CURRENT_TIMESTAMP, paid_by = $1
    WHERE id = $2
    RETURNING *
    `,
    [adminId || null, payoutId]
  );

  return result.rows[0] || null;
}


module.exports = {
  getRaceStatus,
  getRemainingTime,
  getDailyReferralLeaderboard,
  getUserRaceStanding,
  getStarRaceInfo,
  snapshotRaceDay,
  getPendingPayouts,
  markPayoutPaid
};
