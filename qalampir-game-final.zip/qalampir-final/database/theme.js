const { pool, THEME_IDS } = require("./db");


/* =====================================================
   MAVZUNI O'RNATISH
===================================================== */

async function setUserTheme(userId, theme) {
  if (!THEME_IDS.includes(theme)) {
    const error = new Error("Noto'g'ri mavzu");
    error.code = "INVALID_THEME";
    throw error;
  }

  const result = await pool.query(
    `
    UPDATE users
    SET theme = $1, updated_at = CURRENT_TIMESTAMP
    WHERE id = $2
    RETURNING *
    `,
    [theme, userId]
  );

  if (result.rows.length === 0) {
    throw new Error("Foydalanuvchi topilmadi");
  }

  return result.rows[0];
}


module.exports = {
  setUserTheme
};
