const express = require("express");
const router = express.Router();

const { updateGameResult } = require("../database/game");
const { authenticateTelegram } = require("./users");


/* =====================================================
   O'YIN NATIJASINI SAQLASH (initData bilan autentifikatsiya)
===================================================== */

router.post("/game/result", authenticateTelegram, async (req, res) => {
  try {
    const { result } = req.body;

    if (!["win", "loss"].includes(result)) {
      return res.status(400).json({
        success: false,
        error: "Noto'g'ri game result"
      });
    }

    const userId = req.telegramUser.id;
    const updatedUser = await updateGameResult(userId, result);

    res.json({ success: true, user: updatedUser });

  } catch (error) {
    console.error("Game result error:", error);

    res.status(500).json({
      success: false,
      error: "Game result saqlanmadi"
    });
  }
});


module.exports = router;
