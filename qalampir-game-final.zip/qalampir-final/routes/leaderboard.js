const express = require("express");
const router = express.Router();

const { getLeaderboard } = require("../database/leaderboard");


/* =====================================================
   TOP O'YINCHILAR (balans bo'yicha)
===================================================== */

router.get("/leaderboard", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 20, 100);

    const users = await getLeaderboard(limit);

    const leaderboard = users.map(u => ({
      id: u.id,
      username: u.username,
      first_name: u.first_name,
      coins: Number(u.balance),
      wins: u.wins,
      losses: u.losses,
      streak: u.streak,
      level: u.level,
      xp: u.xp
    }));

    res.json({ success: true, leaderboard });

  } catch (error) {
    console.error("Leaderboard error:", error);

    res.status(500).json({
      success: false,
      error: "Leaderboardni olishda xatolik"
    });
  }
});


module.exports = router;
