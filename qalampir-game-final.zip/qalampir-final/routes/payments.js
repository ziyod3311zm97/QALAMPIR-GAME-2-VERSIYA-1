const express = require("express");
const router = express.Router();

const { COIN_PACKAGES } = require("../database/payments");
const { createInvoiceLink } = require("../services/telegramService");


/* =====================================================
   COIN SOTIB OLISH UCHUN INVOICE (Telegram Stars)
===================================================== */

router.post("/create-invoice", async (req, res) => {
  try {
    const { id, packageId } = req.body || {};
    const pkg = COIN_PACKAGES[packageId];

    if (!id || !pkg) {
      return res.status(400).json({
        success: false,
        message: "Noto'g'ri so'rov"
      });
    }

    if (!process.env.BOT_TOKEN) {
      return res.status(500).json({
        success: false,
        message: "To'lov tizimi hozircha sozlanmagan"
      });
    }

    const payload = JSON.stringify({ userId: id, packageId });

    const invoiceLink = await createInvoiceLink({
      title: `${pkg.coins} 🌶️ Qalampir Coin`,
      description: `Qalampir o'yini uchun ${pkg.coins} ta coin`,
      payload,
      prices: [{ label: pkg.label, amount: pkg.stars }]
    });

    res.json({ success: true, invoiceLink });

  } catch (error) {
    console.error("Invoice yaratish xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Invoice yaratib bo'lmadi"
    });
  }
});


module.exports = router;
