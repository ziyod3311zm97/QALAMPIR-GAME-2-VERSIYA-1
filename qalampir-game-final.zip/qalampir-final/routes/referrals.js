const express = require("express");
const router = express.Router();

const {
  getUserReferralStats,
  getTopReferrers,
  buildReferralLink
} = require("../services/referralService");


/* =====================================================
   USERNING REFERRAL STATISTIKASI VA LINKI
===================================================== */

router.get("/referrals/:userId", async (req, res) => {
  try {
    const stats = await getUserReferralStats(req.params.userId);

    const botUsername = process.env.BOT_USERNAME || "QalampirVS_bot";

    res.json({
      success: true,
      stats,
      referralLink: buildReferralLink(botUsername, req.params.userId)
    });

  } catch (error) {
    console.error("Referral stats xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Referral ma'lumotini olishda xatolik"
    });
  }
});


/* =====================================================
   TOP REFERRERLAR (umumiy, hamma vaqt)
===================================================== */

router.get("/referrals-top", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 10, 100);

    const top = await getTopReferrers(limit);

    res.json({ success: true, top });

  } catch (error) {
    console.error("Top referrers xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Ma'lumotni olishda xatolik"
    });
  }
});


module.exports = router;
