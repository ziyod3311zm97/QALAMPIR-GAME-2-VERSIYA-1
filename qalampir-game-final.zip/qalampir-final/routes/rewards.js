const express = require("express");
const router = express.Router();

const { claimDaily } = require("../services/rewardService");


/* =====================================================
   KUNLIK BONUS
===================================================== */

router.post("/daily-bonus", async (req, res) => {
  try {
    const userId = req.body?.id;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: "User id yuborilmadi"
      });
    }

    const { user, amount } = await claimDaily(userId);

    res.json({
      success: true,
      amount,
      user: { coins: Number(user.balance) }
    });

  } catch (error) {

    if (error.code === "ALREADY_CLAIMED") {
      return res.status(400).json({
        success: false,
        code: "ALREADY_CLAIMED",
        message: "Bugungi bonusni allaqachon oldingiz"
      });
    }

    if (error.code === "BANNED") {
      return res.status(403).json({
        success: false,
        code: "BANNED",
        message: "Foydalanuvchi bloklangan"
      });
    }

    console.error("Daily bonus xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Bonusni olishda xatolik"
    });
  }
});


module.exports = router;
