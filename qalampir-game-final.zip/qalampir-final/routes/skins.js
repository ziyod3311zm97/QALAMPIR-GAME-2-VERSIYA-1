const express = require("express");
const router = express.Router();

const { getSkinCatalog, buySkin } = require("../database/skins");


/* =====================================================
   SKINLAR RO'YXATI
===================================================== */

router.post("/skins", async (req, res) => {
  try {
    const userId = req.body?.id;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: "User id yuborilmadi"
      });
    }

    const skins = await getSkinCatalog(userId);

    res.json({ success: true, skins });

  } catch (error) {
    console.error("Skins xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Skinlarni olishda xatolik"
    });
  }
});


/* =====================================================
   SKIN SOTIB OLISH / KIYISH
===================================================== */

router.post("/skins/buy", async (req, res) => {
  try {
    const { id, skin } = req.body || {};

    if (!id || !skin) {
      return res.status(400).json({
        success: false,
        message: "Ma'lumot yetarli emas"
      });
    }

    const updatedUser = await buySkin(id, skin);

    res.json({
      success: true,
      coins: Number(updatedUser.balance),
      equippedSkin: updatedUser.equipped_skin
    });

  } catch (error) {

    if (error.code === "NOT_ENOUGH_COINS") {
      return res.status(400).json({
        success: false,
        code: "NOT_ENOUGH_COINS",
        message: "Coin yetarli emas"
      });
    }

    if (error.code === "SKIN_NOT_FOUND") {
      return res.status(404).json({
        success: false,
        code: "SKIN_NOT_FOUND",
        message: "Skin topilmadi"
      });
    }

    console.error("Skin sotib olish xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Xatolik yuz berdi"
    });
  }
});


module.exports = router;
