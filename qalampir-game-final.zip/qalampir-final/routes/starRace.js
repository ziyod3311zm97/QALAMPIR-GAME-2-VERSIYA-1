const express = require("express");
const router = express.Router();

const { getRaceInfo, getUserStanding } = require("../services/starRaceService");


/* =====================================================
   STAR RACE HOLATI VA TOP-10 (bugungi kun)
===================================================== */

router.get("/star-race", async (req, res) => {
  try {
    const info = await getRaceInfo();

    res.json({ success: true, ...info });

  } catch (error) {
    console.error("Star race xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Star Race ma'lumotini olishda xatolik"
    });
  }
});


/* =====================================================
   USERNING STAR RACE HOLATI
===================================================== */

router.get("/star-race/:userId", async (req, res) => {
  try {
    const standing = await getUserStanding(req.params.userId);

    res.json({ success: true, standing });

  } catch (error) {
    console.error("Star race user xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Ma'lumotni olishda xatolik"
    });
  }
});


module.exports = router;
