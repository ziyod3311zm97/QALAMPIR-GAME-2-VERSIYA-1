const express = require("express");
const router = express.Router();

const { setUserTheme } = require("../database/theme");


/* =====================================================
   MAVZUNI SAQLASH
===================================================== */

router.post("/theme", async (req, res) => {
  try {
    const { id, theme } = req.body || {};

    if (!id || !theme) {
      return res.status(400).json({
        success: false,
        message: "Ma'lumot yetarli emas"
      });
    }

    await setUserTheme(id, theme);

    res.json({ success: true });

  } catch (error) {

    if (error.code === "INVALID_THEME") {
      return res.status(400).json({
        success: false,
        message: "Noto'g'ri mavzu"
      });
    }

    console.error("Theme xatosi:", error);

    res.status(500).json({
      success: false,
      message: "Xatolik yuz berdi"
    });
  }
});


module.exports = router;
