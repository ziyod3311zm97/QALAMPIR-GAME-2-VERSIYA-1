const express = require("express");
const router = express.Router();

const {
  getUser,
  createOrUpdateUser,
  getUserWithFreshEnergy
} = require("../database/users");

const { MAX_ENERGY } = require("../database/db");
const { isDailyBonusAvailable } = require("../database/rewards");
const { validateTelegramInitData } = require("../services/telegramService");


/* =====================================================
   AUTH MIDDLEWARE (Telegram initData HMAC tekshiruvi)
   Boshqa route fayllarida ham ishlatiladi.
===================================================== */

async function authenticateTelegram(req, res, next) {
  try {
    const initData =
      req.headers["x-telegram-init-data"] || req.body?.initData;

    const telegramUser = validateTelegramInitData(initData);

    if (!telegramUser) {
      return res.status(401).json({
        success: false,
        error: "Telegram authentication failed"
      });
    }

    await createOrUpdateUser(telegramUser);

    req.telegramUser = telegramUser;
    next();

  } catch (error) {
    console.error("Authentication error:", error);

    res.status(500).json({
      success: false,
      error: "Authentication server error"
    });
  }
}


/* =====================================================
   HEALTH CHECK
===================================================== */

router.get("/health", (req, res) => {
  res.json({
    success: true,
    message: "Qalampir Game server ishlayapti",
    time: new Date().toISOString()
  });
});


/* =====================================================
   /api/me - initData orqali xavfsiz autentifikatsiya
===================================================== */

router.get("/me", authenticateTelegram, async (req, res) => {
  try {
    const user = await getUser(req.telegramUser.id);

    res.json({ success: true, user });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      error: "User ma'lumotlarini olishda xatolik"
    });
  }
});


/* =====================================================
   /api/user - frontend uchun (Telegram WebApp user obyekti)
===================================================== */

router.post("/user", async (req, res) => {
  try {
    const incomingUser = req.body;

    if (!incomingUser || !incomingUser.id) {
      return res.status(400).json({
        success: false,
        message: "User ma'lumoti yuborilmadi"
      });
    }

    await createOrUpdateUser(incomingUser, incomingUser.referralCode);

    const dbUser = await getUserWithFreshEnergy(incomingUser.id);

    res.json({
      success: true,
      user: {
        id: dbUser.id,
        username: dbUser.username,
        first_name: dbUser.first_name,
        last_name: dbUser.last_name,
        coins: Number(dbUser.balance),
        wins: dbUser.wins,
        losses: dbUser.losses,
        streak: dbUser.streak,
        level: dbUser.level,
        xp: dbUser.xp,
        energy: dbUser.energy,
        maxEnergy: MAX_ENERGY,
        equippedSkin: dbUser.equipped_skin,
        theme: dbUser.theme,
        dailyBonusAvailable: isDailyBonusAvailable(dbUser)
      }
    });

  } catch (error) {
    console.error("api/user xatosi:", error);

    res.status(500).json({
      success: false,
      message: "User ma'lumotlarini olishda xatolik"
    });
  }
});


module.exports = router;
module.exports.authenticateTelegram = authenticateTelegram;
