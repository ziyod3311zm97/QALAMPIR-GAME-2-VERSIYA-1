require("dotenv").config();

const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const { initDatabase } = require("./database/db");
const { registerGameHandlers } = require("./services/gameService");
const { createBot } = require("./bot/bot");

const usersRouter = require("./routes/users");
const gameRouter = require("./routes/game");
const rewardsRouter = require("./routes/rewards");
const leaderboardRouter = require("./routes/leaderboard");
const skinsRouter = require("./routes/skins");
const themeRouter = require("./routes/theme");
const paymentsRouter = require("./routes/payments");
const referralsRouter = require("./routes/referrals");
const starRaceRouter = require("./routes/starRace");


/* =====================================================
   ENV
===================================================== */

const PORT = process.env.PORT || 10000;

const WEB_APP_URL =
  process.env.WEB_APP_URL || "https://qalampir-game.onrender.com";


/* =====================================================
   EXPRESS + HTTP + SOCKET.IO
===================================================== */

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: "*" }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Statik fayllar - faqat public/ papkasidan
app.use(express.static(path.join(__dirname, "public")));


/* =====================================================
   ASOSIY SAHIFA
===================================================== */

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});


/* =====================================================
   REST API
===================================================== */

app.use("/api", usersRouter);
app.use("/api", gameRouter);
app.use("/api", rewardsRouter);
app.use("/api", leaderboardRouter);
app.use("/api", skinsRouter);
app.use("/api", themeRouter);
app.use("/api", paymentsRouter);
app.use("/api", referralsRouter);
app.use("/api", starRaceRouter);


/* =====================================================
   REAL-TIME O'YIN (socket.io)
===================================================== */

registerGameHandlers(io);


/* =====================================================
   SERVERNI ISHGA TUSHIRISH
===================================================== */

async function start() {
  try {
    await initDatabase();

    server.listen(PORT, "0.0.0.0", () => {
      console.log("=================================");
      console.log("🌶️  QALAMPIR GAME");
      console.log("=================================");
      console.log(`🚀 Server port: ${PORT}`);
      console.log(`🌐 Web App: ${WEB_APP_URL}`);
      console.log("✅ Server ishga tushdi");
    });

    createBot(WEB_APP_URL);

  } catch (error) {
    console.error("❌ Server ishga tushirishda xato:", error);
    process.exit(1);
  }
}

start();


/* =====================================================
   GRACEFUL SHUTDOWN
===================================================== */

process.once("SIGINT", () => {
  console.log("🛑 SIGINT...");
  server.close();
  process.exit(0);
});

process.once("SIGTERM", () => {
  console.log("🛑 SIGTERM...");
  server.close();
  process.exit(0);
});
