const { pool } = require("../database/db");


/* =====================================================
   ANTI-CHEAT SOZLAMALARI
===================================================== */

const MAX_REFERRALS_PER_USER_PER_DAY = 100;


/* =====================================================
   USER XAVFSIZLIK MA'LUMOTI
===================================================== */

async function getUserSecurityInfo(userId) {
  const result = await pool.query(
    `
    SELECT id, username, first_name, created_at, referred_by, is_banned
    FROM users
    WHERE id = $1
    `,
    [userId]
  );

  return result.rows[0] || null;
}


/* =====================================================
   O'ZINI-O'ZI TAKLIF QILISH TEKSHIRUVI
===================================================== */

function isSelfReferral(userId, referrerId) {
  return Number(userId) === Number(referrerId);
}


/* =====================================================
   REFERRALNI VALIDATSIYA QILISH
===================================================== */

async function validateReferral(newUserId, referrerId) {

  if (isSelfReferral(newUserId, referrerId)) {
    return { valid: false, reason: "SELF_REFERRAL" };
  }

  const newUser = await getUserSecurityInfo(newUserId);

  if (!newUser) {
    return { valid: false, reason: "NEW_USER_NOT_FOUND" };
  }

  const referrer = await getUserSecurityInfo(referrerId);

  if (!referrer) {
    return { valid: false, reason: "REFERRER_NOT_FOUND" };
  }

  if (newUser.is_banned) {
    return { valid: false, reason: "NEW_USER_BANNED" };
  }

  if (referrer.is_banned) {
    return { valid: false, reason: "REFERRER_BANNED" };
  }

  if (newUser.referred_by) {
    return { valid: false, reason: "ALREADY_REFERRED" };
  }

  return { valid: true };
}


/* =====================================================
   KUNLIK REFERRAL LIMITI
===================================================== */

async function getTodayReferralCount(userId) {
  const result = await pool.query(
    `
    SELECT COUNT(*)::int AS count
    FROM users
    WHERE referred_by = $1 AND created_at >= CURRENT_DATE
    `,
    [userId]
  );

  return result.rows[0].count;
}

async function checkReferralDailyLimit(userId) {
  const count = await getTodayReferralCount(userId);

  return {
    allowed: count < MAX_REFERRALS_PER_USER_PER_DAY,
    count,
    limit: MAX_REFERRALS_PER_USER_PER_DAY
  };
}


module.exports = {
  MAX_REFERRALS_PER_USER_PER_DAY,
  getUserSecurityInfo,
  isSelfReferral,
  validateReferral,
  getTodayReferralCount,
  checkReferralDailyLimit
};
