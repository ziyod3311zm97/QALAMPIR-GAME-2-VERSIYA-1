const { spendEnergy } = require("../database/users");
const { updateGameResult } = require("../database/game");


/* =====================================================
   QALAMPIR DUEL - O'YIN HOLATI (in-memory)
===================================================== */

const waitingQueue = [];      // [{ socketId, user }]
const rooms = new Map();      // roomId -> room
const roomCodes = new Map();  // roomCode -> roomId

function generateRoomId() {
  return "room_" + Math.random().toString(36).slice(2, 10);
}

function generateRoomCode() {
  let code;

  do {
    code = String(Math.floor(1000 + Math.random() * 9000));
  } while (roomCodes.has(code));

  return code;
}

function findPlayer(room, socketId) {
  return room.players.find(p => p.socketId === socketId);
}

function otherPlayer(room, socketId) {
  return room.players.find(p => p.socketId !== socketId);
}

async function recordGameResult(userId, result) {
  try {
    if (!userId || userId === "demo") {
      return;
    }

    await updateGameResult(userId, result);

  } catch (error) {
    console.error("O'yin natijasini saqlashda xatolik:", error);
  }
}

function cleanupRoom(room) {
  if (room.code) {
    roomCodes.delete(room.code);
  }

  rooms.delete(room.id);
}

function energyErrorMessage(error) {
  if (error.code === "BANNED") {
    return "🚫 Siz bloklangansiz. O'yin o'ynay olmaysiz.";
  }

  if (error.code === "NO_ENERGY") {
    return "🔋 Jon tugadi! Biroz kuting (har 10 daqiqada +1 jon) yoki do'kondan sotib oling.";
  }

  return "Xatolik yuz berdi, qayta urinib ko'ring.";
}


/* =====================================================
   BOT AI
===================================================== */

function scheduleBotAttack(io, room) {
  setTimeout(() => {

    if (!rooms.has(room.id) || room.phase !== "BATTLE") {
      return;
    }

    const bot = room.players.find(p => p.isBot);
    const human = otherPlayer(room, bot.socketId);

    if (!human || room.turn !== bot.socketId) {
      return;
    }

    room.botAttacked = room.botAttacked || new Set();

    let spot;

    do {
      spot = Math.floor(Math.random() * 6);
    } while (room.botAttacked.has(spot));

    room.botAttacked.add(spot);

    resolveAttack(io, room, bot, spot);

  }, 1000 + Math.random() * 1200);
}

function startBattlePhase(io, room) {
  room.phase = "BATTLE";

  const starter = room.players[Math.floor(Math.random() * 2)];
  room.turn = starter.socketId;

  room.players.forEach(p => {
    if (!p.isBot) {
      io.to(p.socketId).emit("battleStart", { turn: room.turn });
    }
  });

  if (starter.isBot) {
    scheduleBotAttack(io, room);
  }
}

function checkBothReady(io, room) {
  const bothSet = room.players.every(p => p.spot !== null);

  if (bothSet) {
    startBattlePhase(io, room);
  }
}

function resolveAttack(io, room, attacker, spot) {
  const defender = otherPlayer(room, attacker.socketId);

  if (!defender) {
    return;
  }

  const isHit = defender.spot === spot;

  if (isHit) {
    room.phase = "END";

    room.players.forEach(p => {
      if (!p.isBot) {
        io.to(p.socketId).emit("gameOver", {
          winner: attacker.socketId,
          hitSpot: spot
        });
      }
    });

    if (!attacker.isBot) {
      recordGameResult(attacker.user?.id, "win");
    }

    if (!defender.isBot) {
      recordGameResult(defender.user?.id, "loss");
    }

    cleanupRoom(room);

  } else {

    room.turn = defender.socketId;

    room.players.forEach(p => {
      if (!p.isBot) {
        io.to(p.socketId).emit("turnChanged", {
          attacker: attacker.socketId,
          spot,
          nextTurn: room.turn
        });
      }
    });

    if (defender.isBot) {
      scheduleBotAttack(io, room);
    }
  }
}


/* =====================================================
   SOCKET.IO HANDLERLARINI ULASH
===================================================== */

function registerGameHandlers(io) {

  io.on("connection", socket => {

    console.log("Socket connected:", socket.id);


    /* ---------- TEZKOR O'YIN ---------- */

    socket.on("joinRandomGame", async user => {

      try {
        await spendEnergy(user.id);
      } catch (error) {
        socket.emit("errorMsg", energyErrorMessage(error));
        return;
      }

      const staleIdx = waitingQueue.findIndex(w => w.socketId === socket.id);

      if (staleIdx !== -1) {
        waitingQueue.splice(staleIdx, 1);
      }

      if (waitingQueue.length > 0) {

        const opponent = waitingQueue.shift();
        const roomId = generateRoomId();

        const room = {
          id: roomId,
          code: null,
          phase: "PLACE",
          turn: null,
          players: [
            { socketId: opponent.socketId, user: opponent.user, spot: null, isBot: false },
            { socketId: socket.id, user, spot: null, isBot: false }
          ]
        };

        rooms.set(roomId, room);

        io.to(opponent.socketId).emit("gameMatched", { roomId, opponent: user });
        io.to(socket.id).emit("gameMatched", { roomId, opponent: opponent.user });

      } else {

        waitingQueue.push({ socketId: socket.id, user });
        socket.emit("waitingForOpponent");

        setTimeout(() => {

          const stillWaitingIdx = waitingQueue.findIndex(w => w.socketId === socket.id);

          if (stillWaitingIdx === -1) {
            return;
          }

          waitingQueue.splice(stillWaitingIdx, 1);

          const roomId = generateRoomId();

          const room = {
            id: roomId,
            code: null,
            phase: "PLACE",
            turn: null,
            players: [
              { socketId: socket.id, user, spot: null, isBot: false },
              {
                socketId: "bot_" + roomId,
                user: { first_name: "Bot 🤖" },
                spot: Math.floor(Math.random() * 6),
                isBot: true
              }
            ]
          };

          rooms.set(roomId, room);

          io.to(socket.id).emit("gameMatched", {
            roomId,
            opponent: room.players[1].user
          });

        }, 6000);
      }
    });


    /* ---------- DO'ST BILAN O'YNASH ---------- */

    socket.on("createPrivateRoom", async user => {

      try {
        await spendEnergy(user.id);
      } catch (error) {
        socket.emit("errorMsg", energyErrorMessage(error));
        return;
      }

      const roomId = generateRoomId();
      const code = generateRoomCode();

      const room = {
        id: roomId,
        code,
        phase: "WAITING",
        turn: null,
        players: [{ socketId: socket.id, user, spot: null, isBot: false }]
      };

      rooms.set(roomId, room);
      roomCodes.set(code, roomId);

      socket.emit("roomCreated", { roomId, roomCode: code });
    });


    socket.on("joinPrivateRoom", async ({ roomCode, userData } = {}) => {

      const roomId = roomCodes.get(roomCode);
      const room = roomId && rooms.get(roomId);

      if (!room || room.players.length >= 2) {
        socket.emit("errorMsg", "Xona topilmadi yoki allaqachon to'lgan.");
        return;
      }

      try {
        await spendEnergy(userData.id);
      } catch (error) {
        socket.emit("errorMsg", energyErrorMessage(error));
        return;
      }

      room.players.push({ socketId: socket.id, user: userData, spot: null, isBot: false });
      room.phase = "PLACE";

      roomCodes.delete(roomCode);

      room.players.forEach(p => {
        io.to(p.socketId).emit("gameMatched", {
          roomId: room.id,
          opponent: otherPlayer(room, p.socketId).user
        });
      });
    });


    /* ---------- QALAMPIRNI YASHIRISH ---------- */

    socket.on("setSpot", ({ roomId, spot } = {}) => {

      const room = rooms.get(roomId);

      if (!room || room.phase !== "PLACE") {
        return;
      }

      const player = findPlayer(room, socket.id);

      if (!player || typeof spot !== "number" || spot < 0 || spot > 5) {
        return;
      }

      player.spot = spot;

      checkBothReady(io, room);
    });


    /* ---------- HUJUM ---------- */

    socket.on("attackSpot", ({ roomId, spot } = {}) => {

      const room = rooms.get(roomId);

      if (!room || room.phase !== "BATTLE" || room.turn !== socket.id) {
        return;
      }

      const attacker = findPlayer(room, socket.id);

      if (!attacker || typeof spot !== "number" || spot < 0 || spot > 5) {
        return;
      }

      resolveAttack(io, room, attacker, spot);
    });


    /* ---------- ULANISH UZILISHI ---------- */

    socket.on("disconnect", () => {

      console.log("Socket disconnected:", socket.id);

      const qIdx = waitingQueue.findIndex(w => w.socketId === socket.id);

      if (qIdx !== -1) {
        waitingQueue.splice(qIdx, 1);
      }

      for (const room of rooms.values()) {

        const player = findPlayer(room, socket.id);

        if (!player) {
          continue;
        }

        const opponent = otherPlayer(room, socket.id);

        if (opponent && !opponent.isBot) {
          io.to(opponent.socketId).emit("errorMsg", "Raqib o'yindan chiqib ketdi.");
        }

        cleanupRoom(room);
      }
    });

  });
}


module.exports = {
  registerGameHandlers
};
