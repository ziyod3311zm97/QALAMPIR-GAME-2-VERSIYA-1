const {
  getReferralInfo,
  getReferralCount,
  getReferrals,
  getReferralLeaderboard
} = require("../database/referrals");


/* =====================================================
   USER REFERRAL STATISTIKASI
===================================================== */

async function getUserReferralStats(userId) {
  const info = await getReferralInfo(userId);
  const count = await getReferralCount(userId);

  return {
    userId,
    referredBy: info?.referred_by || null,
    referrerUsername: info?.referrer_username || null,
    referralCount: count
  };
}


/* =====================================================
   REFERRAL QILINGAN USERLAR
===================================================== */

async function getUserReferrals(userId, limit = 100) {
  return await getReferrals(userId, limit);
}


/* =====================================================
   UMUMIY TOP REFERRERLAR
===================================================== */

async function getTopReferrers(limit = 10) {
  return await getReferralLeaderboard(limit);
}


/* =====================================================
   REFERRAL LINK GENERATSIYA
===================================================== */

function buildReferralLink(botUsername, userId) {
  return `https://t.me/${botUsername}?start=ref_${userId}`;
}


module.exports = {
  getUserReferralStats,
  getUserReferrals,
  getTopReferrers,
  buildReferralLink
};
