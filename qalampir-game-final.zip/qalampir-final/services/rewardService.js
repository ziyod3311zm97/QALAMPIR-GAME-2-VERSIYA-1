const { claimDailyBonus, isDailyBonusAvailable } = require("../database/rewards");
const { addCoins } = require("../database/users");


/* =====================================================
   KUNLIK BONUS
===================================================== */

async function claimDaily(userId) {
  return await claimDailyBonus(userId);
}


/* =====================================================
   QO'LDA COIN MUKOFOTI (admin, star race va h.k.)
===================================================== */

async function giveCoinReward(userId, amount, type) {
  const rewardAmount = Math.floor(Number(amount));

  if (!Number.isFinite(rewardAmount) || rewardAmount === 0) {
    throw new Error("Reward miqdori noto'g'ri");
  }

  return await addCoins(userId, rewardAmount, type);
}


module.exports = {
  claimDaily,
  isDailyBonusAvailable,
  giveCoinReward
};
