const {
  getStarRaceInfo,
  getUserRaceStanding,
  snapshotRaceDay,
  getPendingPayouts,
  markPayoutPaid
} = require("../database/starRace");


/* =====================================================
   RACE MA'LUMOTLARI (frontendga)
===================================================== */

async function getRaceInfo() {
  return await getStarRaceInfo();
}


/* =====================================================
   USERNING HOLATI
===================================================== */

async function getUserStanding(userId) {
  return await getUserRaceStanding(userId);
}


/* =====================================================
   KUNNI "MUZLATISH" (admin: /racesnapshot [YYYY-MM-DD])
   Odatda kun tugagach, kechagi TOP-10'ni yozib qo'yish uchun.
===================================================== */

function yesterdayDate() {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - 1);
  return d.toISOString().slice(0, 10);
}

async function snapshotDay(raceDate) {
  const date = raceDate || yesterdayDate();
  const inserted = await snapshotRaceDay(date);

  return { raceDate: date, inserted };
}


/* =====================================================
   TO'LANMAGAN MUKOFOTLAR (admin: /racelist)
===================================================== */

async function listPendingPayouts(limit = 50) {
  return await getPendingPayouts(limit);
}


/* =====================================================
   MUKOFOTNI QO'LDA "TO'LANDI" DEB BELGILASH
   (admin haqiqatda Telegram Stars/pul yuborgandan keyin)
===================================================== */

async function payOut(payoutId, adminId) {
  return await markPayoutPaid(payoutId, adminId);
}


module.exports = {
  getRaceInfo,
  getUserStanding,
  snapshotDay,
  listPendingPayouts,
  payOut
};
