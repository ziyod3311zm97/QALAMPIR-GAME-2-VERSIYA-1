const crypto = require("crypto");


/* =====================================================
   TELEGRAM initData TEKSHIRISH (HMAC)
   Mini App'dan kelgan foydalanuvchi ma'lumotini
   Telegram tomonidan imzolanganini tasdiqlaydi.
===================================================== */

function validateTelegramInitData(initData) {
  if (!initData) {
    return null;
  }

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");

  if (!hash) {
    return null;
  }

  params.delete("hash");

  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");

  const botToken = process.env.BOT_TOKEN;

  if (!botToken) {
    console.error("BOT_TOKEN topilmadi.");
    return null;
  }

  const secretKey = crypto
    .createHmac("sha256", "WebAppData")
    .update(botToken)
    .digest();

  const calculatedHash = crypto
    .createHmac("sha256", secretKey)
    .update(dataCheckString)
    .digest("hex");

  if (calculatedHash !== hash) {
    return null;
  }

  const authDate = Number(params.get("auth_date"));

  if (!authDate) {
    return null;
  }

  const maxAge = Number(process.env.TELEGRAM_AUTH_MAX_AGE) || 86400;
  const currentTime = Math.floor(Date.now() / 1000);

  if (currentTime - authDate > maxAge) {
    return null;
  }

  const userString = params.get("user");

  if (!userString) {
    return null;
  }

  try {
    return JSON.parse(userString);
  } catch (error) {
    return null;
  }
}


/* =====================================================
   TELEGRAM STARS INVOICE LINK YARATISH
===================================================== */

async function createInvoiceLink({ title, description, payload, prices }) {
  const response = await fetch(
    `https://api.telegram.org/bot${process.env.BOT_TOKEN}/createInvoiceLink`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title,
        description,
        payload,
        currency: "XTR",
        prices
      })
    }
  );

  const data = await response.json();

  if (!data.ok) {
    throw new Error(data.description || "Invoice yaratib bo'lmadi");
  }

  return data.result;
}


module.exports = {
  validateTelegramInitData,
  createInvoiceLink
};
